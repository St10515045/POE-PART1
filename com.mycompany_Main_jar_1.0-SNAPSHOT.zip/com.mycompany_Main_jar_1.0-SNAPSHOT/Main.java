package com.mycompany.main.java;

import java.util.Scanner;

class Login {

    private String storedUsername;
    private String storedPassword;
    private String storedPhone;

    // Username validation
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Password validation
    public boolean checkPasswordComplexity(String password) {

        if (password.length() < 8) return false;

        boolean hasUpper = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasUpper = true;
            } else if (Character.isDigit(ch)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(ch)) {
                hasSpecial = true;
            }
        }

        return hasUpper && hasNumber && hasSpecial;
    }

    // Cell phone validation
    public boolean checkCellPhoneNumber(String phoneNumber) {

        if (!phoneNumber.startsWith("+27")) return false;
        if (phoneNumber.length() != 12) return false;

        for (int i = 3; i < phoneNumber.length(); i++) {
            if (!Character.isDigit(phoneNumber.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    // Register user
    public String registerUser(String username, String password, String phoneNumber) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted. It must contain '_' and be no more than 5 characters.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted. It must be at least 8 characters, include a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(phoneNumber)) {
            return "Cell phone number incorrectly formatted. It must start with +27 and be 12 digits long.";
        }

        storedUsername = username;
        storedPassword = password;
        storedPhone = phoneNumber;

        return "User registered successfully!";
    }

    // Login user
    public boolean loginUser(String username, String password) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    // Return login status
    public String returnLoginStatus(boolean status) {
        if (status) {
            return "Welcome back! Login successful.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Login user = new Login();

        // REGISTER
        System.out.println("=== REGISTER ===");

        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        System.out.print("Enter cell phone number (+27...): ");
        String phone = sc.nextLine();

        String registerMessage = user.registerUser(username, password, phone);
        System.out.println(registerMessage);

        // LOGIN
        System.out.println("\n=== LOGIN ===");

        System.out.print("Enter username: ");
        String loginUsername = sc.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = sc.nextLine();

        boolean loginStatus = user.loginUser(loginUsername, loginPassword);
        String loginMessage = user.returnLoginStatus(loginStatus);

        System.out.println(loginMessage);

        sc.close();
    }
}